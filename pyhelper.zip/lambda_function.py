import os
from crhelper import CfnResource
import boto3
from botocore.exceptions import ClientError

helper = CfnResource()



@helper.create
@helper.update
def dispatch(event, _):
    op = event['ResourceProperties']['Operation']
    print("Helper {0} {1}".format(event['RequestType'], op))
    if op == 'cp':
        return cp(event, _)
    elif op == 'cpdir':
        return cpdir(event, _)
    elif op == 'mkdir':
        return mkdir(event, _)
    elif op == 'notification':
        return notification(event, _)

def notification(event, _):
    bucket = event['ResourceProperties']['Bucket']
    # this is the LambdaConfiguration Id
    key = event['ResourceProperties']['Key']
    try:
        s3 = boto3.client('s3')
        response = s3.get_bucket_notification_configuration(Bucket=bucket)
        lcf = response['LambdaFunctionConfigurations']
        lcf[0]['Id'] = key
        response = s3.put_bucket_notification_configuration(Bucket=bucket,
                NotificationConfiguration={'LambdaFunctionConfigurations': lcf})
    except ClientError as e:
        print("Failed to update notification {0}:{1} -> {2}".format(bucket, key, e))

def cp(event, _):
    bucket = event['ResourceProperties']['Bucket']
    key = event['ResourceProperties']['Key']
    frombucket = event['ResourceProperties']['FromBucket']
    if 'FromKey' in event['ResourceProperties']:
        fromkey = event['ResourceProperties']['FromKey']
    else:
        fromkey = key
    subs = list()
    if 'Substitute' in event['ResourceProperties']:
        subs = event['ResourceProperties']['Substitute']
    if 'Acl' in event['ResourceProperties']:
        acl = event['ResourceProperties']['Acl']
    else:
        acl = 'bucket-owner-full-control'
    try:
        s3 = boto3.client('s3')
        if len(subs) == 0:
            response = s3.copy_object(CopySource = {'Bucket': frombucket, 'Key': fromkey}, \
                                         Bucket=bucket, Key=key, ACL=acl)
        else:
            obj = s3.get_object(Bucket=frombucket, Key=fromkey)
            content = obj['Body'].read().decode('utf-8')
            index = 1
            for sub in subs:
               content = content.replace('Substitute{}'.format(index), sub)
               index += 1
            #print("Content: {}".format(content))
            s3.put_object(Bucket=bucket, Key=key, ACL=acl, Body=bytes(content, 'utf-8'))
    except ClientError as e:
        print("Failed to copy {0}:{1} -> {2}".format(bucket, key, e))

def cpdir(event, _):
    bucket = event['ResourceProperties']['Bucket']
    key = event['ResourceProperties']['Key']+'/'
    frombucket = event['ResourceProperties']['FromBucket']
    if 'FromKey' in event['ResourceProperties']:
        fromkey = event['ResourceProperties']['FromKey']+'/'
    else:
        fromkey = key
    try:
        s3 = boto3.client('s3')
        resp = s3.list_objects_v2(Bucket=frombucket, Prefix=fromkey, Delimiter='/')
        for obj in resp.get('Contents'):
            objkey = obj['Key']
            if objkey == key: continue
            newkey = key + os.path.basename(objkey)
            response = s3.copy_object(CopySource = {'Bucket': frombucket, 'Key': objkey}, \
                                      Bucket=bucket, Key=newkey, ACL='bucket-owner-full-control')
    except ClientError as e:
        print("Failed to copydir {0}:{1} -> {2}".format(bucket, key, e))

def mkdir(event, _):
    bucket = event['ResourceProperties']['Bucket']
    key = event['ResourceProperties']['Key']
    try:
        s3 = boto3.client('s3')
        if not objexists(s3, bucket, key):
            s3.put_object(Bucket=bucket, Body='', Key=key, ACL='bucket-owner-full-control')
    except ClientError as e:
        print("Failed to mkdir {0}:{1} -> {2}".format(bucket, key, e))

def objexists(s3, bucket, key):
    try:
        fileobj = s3.list_objects_v2(Bucket=bucket, Prefix=key)
        return 'Contents' in fileobj
    except ClientError as e:
        print("objexist {0}:{1} -> {2}".format(bucket, key, e))
        return False

@helper.delete
def delete(event, _):
    op = event['ResourceProperties']['Operation']
    if op == 'delbucket':
        print("Helper {0} {1} {2}".format(event['RequestType'], op, event['ResourceProperties']['Bucket']))
    else:
        print("Helper {0} {1}".format(event['RequestType'], op))
    if op == 'cp' or op == 'mkdir':
        bucket = event['ResourceProperties']['Bucket']
        key = event['ResourceProperties']['Key']
        try:
            s3 = boto3.client('s3')
            if objexists(s3, bucket, key):
                s3.delete_object(Bucket=bucket, Key=key)
        except ClientError as e:
            print("Failed to delete {0}:{1} -> {2}".format(bucket, key, e))
    elif op == 'delecr':
        ecrkey = event['ResourceProperties']['ECR']
        try:
            sts = boto3.client('sts')
            account = sts.get_caller_identity().get('Account')
            ecr = boto3.client('ecr')
            ecr.delete_repository(registryId=account, repositoryName=ecrkey, force=True)
        except ClientError as e:
            print("Failed to delete ECR: {0} -> {1}".format(ecrkey, e))
    elif op == 'delgateway':
        bucket = event['ResourceProperties']['Bucket']
        gw = boto3.client('storagegateway')
        try:
            gateways = gw.list_gateways().get('Gateways')
            for gate in gateways:
                if gate['GatewayName'] == bucket:
                    print("Deleting {0}".format(gate['GatewayARN']))
                    gw.delete_gateway(GatewayARN=gate['GatewayARN'])
        except ClientError as e:
            print("Failed to delete StorageGateway: {0} -> {1}".format(bucket, e))
    elif op == 'delbucket':
        bucket = event['ResourceProperties']['Bucket']
        try:
            obj = 'none'
            s3 = boto3.client('s3')
            fileobj = s3.list_objects_v2(Bucket=bucket)
            if 'Contents' in fileobj:
                for obj in fileobj['Contents']:
                    print("delete {}".format(obj['Key']))
                    s3.delete_object(Bucket=bucket, Key=obj['Key'])
            fileobj = s3.list_object_versions(Bucket=bucket)
            if 'Versions' in fileobj:
                for obj in fileobj['Versions']:
                    print("delete version {}".format(obj['Key']))
                    s3.delete_object(Bucket=bucket, Key=obj['Key'], VersionId=obj['VersionId'])
            if 'DeleteMarkers' in fileobj:
                for obj in fileobj['DeleteMarkers']:
                    print("delete marker {}".format(obj['Key']))
                    s3.delete_object(Bucket=bucket, Key=obj['Key'], VersionId=obj['VersionId'])
            s3.delete_bucket(Bucket=bucket)
        except ClientError as e:
            print("Failed to delete bucket {0}:{1} -> {2}".format(bucket, obj, e))
    elif op == 'delgroup':
        group = event['ResourceProperties']['Group']
        try:
            iam = boto3.client('iam')
            users = iam.get_group(GroupName=group).get('Users')
            for user in users:
                iam.remove_user_from_group(GroupName=group, UserName=user['UserName'])
            # we would need to delete policies, but CFN can do this, it just won't remove users it didn't add
            #iam.delete_group(GroupName=group)
        except ClientError as e:
            print("Failed to delete group {0} -> {1}".format(group, e))


def handler(event, context):
    helper(event, context)
